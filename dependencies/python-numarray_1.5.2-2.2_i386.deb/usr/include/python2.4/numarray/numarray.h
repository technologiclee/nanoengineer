/* $Id: numarray.h,v 1.29 2004/06/09 14:24:54 jaytmiller Exp $ */ 

#if !defined(_numarray)
#define _numarray

#include "libnumarray.h"

#endif  /* _numarray */
