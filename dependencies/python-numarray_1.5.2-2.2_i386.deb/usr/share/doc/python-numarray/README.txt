See the Doc directory for more numarray documentation, including
CHANGES for this release and installation instructions.

See http://sourceforge.net/projects/numpy for the source forge website
for Numeric and Numarray featuring CVS, Bug Tracking, Downloads, etc.
If you make a submission to a tracker, make sure that it has a
"Numarray" prefix, i.e. "Numarray Bugs" and not just "Bugs".
Unadorned trackers belong to Numeric.

See http://stsdas.stsci.edu/numarray/ for additional Numarray
documentation and the Numarray manual.  This is the Numarray homepage
managed by Perry Greenfield at STSCI.

See http://pfdubois.com/numpy/ for additional Numeric documentation
and the NumPy manual.  This is the Numeric homepage managed by Paul
Dubois.

