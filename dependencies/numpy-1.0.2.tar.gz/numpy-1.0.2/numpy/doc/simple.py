import numpy

a = numpy.arange(100 * 100)
a = a.reshape(100, 100)
b = a

def p(x, y):
        print x, y
        return x

v = numpy.vectorize(p)
print v(a,b)

