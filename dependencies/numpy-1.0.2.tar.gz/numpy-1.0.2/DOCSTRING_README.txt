
Both NumPy and SciPy follow a convention for docstrings that provide
for some consistency while also allowing epydoc to produce
nicely-formatted reference guides. 

The docstring format uses reST syntax as interpreted by epydoc
(which should understand how to process some of our conventions at
some point)

Here is an example:

"""
one-line summary or signature

Several sentences providing an extended description

:Parameters:
    var1 : type information
        Explanation
    var2 : type information
        Explanation
    long_variable_name : 
        Explanation

:Parameters2:
    only_seldom_used_keywords : type
        Explanation
    common_parametrs_listed_above : type
        Explanation





